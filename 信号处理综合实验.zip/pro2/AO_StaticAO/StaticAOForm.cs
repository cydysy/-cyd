using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using Automation.BDaq;
using System.IO;

namespace AO_StaticAO
{
    public partial class StaticAOForm : Form
    {
        #region fileds
        int m_channelStart = 0;
        int m_channelCount = 0;
        uint m_PointCountPerWave;
        double[] m_dataScaled = new double[2];
        int m_wavePointsIndexA = 0;
        int m_wavePointsIndexB = 0;
        double m_highLevelA;
        double m_lowLevelA;
        double m_highLevelB;
        double m_lowLevelB;
        private bool m_isCheckedA;
        private bool m_isCheckedB;
        WaveformGenerator m_waveformGenerator;
        WaveformStyle m_formStyleA;
        WaveformStyle m_formStyleB;
        ErrorCode m_err = ErrorCode.Success;
        CheckBox[] m_waveSelectCheckBox = new CheckBox[6];

        #endregion
        double time_count = 0;
        bool flag_start = false;
        double time_fre;
        double totalpoints;
        bool open_file = true;
        double[] file_x = new double[10000];
        double[] file_y = new double[10000];
        int len = 0;
        int len_count=0;
        public StaticAOForm()
        {
            InitializeComponent();
        }

        private void InstantAoForm_Load(object sender, EventArgs e)
        {
            //The default device of project is demo device, users can choose other devices according to their needs. 
            //initialize a timer which drive the data acquisition.
            timer_outputData.Interval = 50;
            totalpoints = double.PositiveInfinity;
            //initialize the scrollbar
            trackBar_Scroll.Maximum = 1000;
            trackBar_Scroll.Minimum = 10;
            trackBar_Scroll.Value = 50;
            //initialize the pointperperiod 
            textBox1.ReadOnly = false;
            m_PointCountPerWave = uint.Parse(textBox1.Text);
            time_fre = double.Parse(textBox2.Text);
            //initialize the checkbox
            m_waveSelectCheckBox[0] = checkBox_sineA;
            m_waveSelectCheckBox[1] = checkBox_squareA;
            m_waveSelectCheckBox[2] = checkBox_triangleA;
            m_waveSelectCheckBox[3] = checkBox_sineB;
            m_waveSelectCheckBox[4] = checkBox_squareB;
            m_waveSelectCheckBox[5] = checkBox_triangleB;
            //initialize a graph with a picture box control to draw Ai data. 

            // no device is selected
            if (!m_instantAoCtrl.Initialized)
            {
                MessageBox.Show("No device be selected or device open failed!", "StaticAO");
                this.Close();
                return;
            }

            m_waveformGenerator = new WaveformGenerator(m_PointCountPerWave);
            //set title of the form.
            string text = m_instantAoCtrl.SelectedDevice.Description;
            this.Text = "Static AO(" + text + ")";
            ConfigurePanel();

        }

        private void ConfigurePanel()
        {
            if (m_instantAoCtrl.ChannelCount == 1)
            {
                m_channelStart = 0;
                m_channelCount = 1;
                for (int i = 3; i < 6; i++)
                {
                    m_waveSelectCheckBox[i].Enabled = false;
                }
                textBox_highLevelB.Enabled = false;
                textBox_lowLevelB.Enabled = false;
                textBox_valueB.Enabled = false;
                button_manualB.Enabled = false;
                label_chanB.Text = " ";
            }
            else
            {
                m_channelStart = 0;
                m_channelCount = 2;
                for (int i = 3; i < 6; i++)
                {
                    m_waveSelectCheckBox[i].Enabled = true;
                }
                textBox_highLevelB.Enabled = true;
                textBox_lowLevelB.Enabled = true;
                textBox_valueB.Enabled = true;
                button_manualB.Enabled = true;
                int chanNumberB = m_channelStart + 1;
                label_chanB.Text = chanNumberB.ToString();
            }
            label_chanA.Text = m_channelStart.ToString();
        }

        private void CheckError(ErrorCode err)
        {
            if (err != ErrorCode.Success)
            {
                timer_outputData.Stop();
                MessageBox.Show("Error: " + err.ToString());
            }
        }

        private void timer_outputData_Tick(object sender, EventArgs e)
        {
            if (open_file)
            {
                time_count++;
                if (m_isCheckedA)
                {

                    m_dataScaled[0] = m_waveformGenerator.GetOnePoint(m_formStyleA, m_wavePointsIndexA++, m_highLevelA, m_lowLevelA);
                    if (m_wavePointsIndexA == m_PointCountPerWave)
                    {
                        m_wavePointsIndexA = 0;
                    }
                }
                if (m_isCheckedB)
                {

                    if (m_channelCount > 1)
                    {
                        m_dataScaled[1] = m_waveformGenerator.GetOnePoint(m_formStyleB, m_wavePointsIndexB++, m_highLevelB, m_lowLevelB);
                    }
                    if (m_wavePointsIndexB == m_PointCountPerWave)
                    {
                        m_wavePointsIndexB = 0;
                    }
                }
              
                if (flag_start)
                {
                    if (m_isCheckedA)
                    {
                        if (time_count * timer_outputData.Interval < chart1.ChartAreas[0].AxisX.Maximum)
                            chart1.Series["Series1"].Points.AddXY(time_count * timer_outputData.Interval, m_dataScaled[0]);
                        else
                        {
                            chart1.Series["Series1"].Points.Clear();
                            chart1.ChartAreas[0].AxisX.Minimum = 4000 * (int)(time_count * timer_outputData.Interval / 4000);
                            chart1.ChartAreas[0].AxisX.Maximum = chart1.ChartAreas[0].AxisX.Minimum + 4000;
                            chart1.Series["Series1"].Points.AddXY(time_count * timer_outputData.Interval, m_dataScaled[0]);
                        }
                    }

                    if (m_isCheckedB)
                    {
                        if (time_count * timer_outputData.Interval < chart1.ChartAreas[0].AxisX.Maximum)
                            chart1.Series["Series2"].Points.AddXY(time_count * timer_outputData.Interval, m_dataScaled[1]);
                        else
                        {
                            chart1.Series["Series2"].Points.Clear();
                            chart1.ChartAreas[0].AxisX.Minimum = 4000 * (int)(time_count * timer_outputData.Interval / 4000);
                            chart1.ChartAreas[0].AxisX.Maximum = chart1.ChartAreas[0].AxisX.Minimum + 4000;
                            chart1.Series["Series2"].Points.AddXY(time_count * timer_outputData.Interval, m_dataScaled[1]);
                        }
                    }
                }
                if (time_count >= totalpoints)
                    timer_outputData.Stop();
            }
            else
            {
                if (len_count < len)
                {
                    m_dataScaled[0] = file_y[len_count];
                    //if (file_x[len_count]<4000)
                    chart1.Series["Series1"].Points.AddXY(file_x[len_count], m_dataScaled[0]);
                    //else
                    //{
                    //    chart1.Series["Series1"].Points.Clear();
                    //    chart1.ChartAreas[0].AxisX.Minimum = 4000 * (int)(file_x[len_count] / 4000);
                    //    chart1.ChartAreas[0].AxisX.Maximum = chart1.ChartAreas[0].AxisX.Minimum + 4000;
                    //    chart1.Series["Series1"].Points.AddXY(file_x[len_count], m_dataScaled[0]);
                   // }
                    len_count++;
                }
            }
            m_err = m_instantAoCtrl.Write(m_channelStart, m_channelCount, m_dataScaled);
            CheckError(m_err);

        }

        private void checkBox_AoDataOut_MouseClick(object sender, MouseEventArgs e)
        {
            chart1.Series["Series1"].Points.Clear();
            chart1.Series["Series2"].Points.Clear();
            time_count = 0;
            chart1.ChartAreas[0].AxisX.Minimum = 0;
            chart1.ChartAreas[0].AxisX.Maximum = 4000;
            int index = Array.IndexOf(m_waveSelectCheckBox, sender);
            CheckBox currentcheckedBox = (CheckBox)sender;
            if (currentcheckedBox.Checked)
            {
                if (index < 3)
                {

                    // make all the checkBoxes is unchecked
                    for (int i = 0; i < 3; i++)
                    {
                        m_waveSelectCheckBox[i].Checked = false;
                        m_waveSelectCheckBox[i].BackgroundImage = imageList.Images[i];
                    }
                    // make the checkBox clicked is checked
                    m_waveSelectCheckBox[index].BackgroundImage = imageList.Images[index + 3];
                    // read the user input value
                    double.TryParse(textBox_highLevelA.Text, out m_highLevelA);
                    double.TryParse(textBox_lowLevelA.Text, out m_lowLevelA);
                    m_isCheckedA = true;
                    m_wavePointsIndexA = 0;
                    m_formStyleA = (WaveformStyle)(index % 3);
                }
                else
                {
                    for (int j = 3; j < 6; j++)
                    {
                        m_waveSelectCheckBox[j].Checked = false;
                        m_waveSelectCheckBox[j].BackgroundImage = imageList.Images[j - 3];
                    }
                    m_waveSelectCheckBox[index].BackgroundImage = imageList.Images[index];
                    double.TryParse(textBox_highLevelB.Text, out m_highLevelB);
                    double.TryParse(textBox_lowLevelB.Text, out m_lowLevelB);
                    m_isCheckedB = true;
                    m_wavePointsIndexB = 0;
                    m_formStyleB = (WaveformStyle)(index % 3);
                }
                currentcheckedBox.Checked = true;
            }
            else
            {
                if (index < 3)
                {
                    m_waveSelectCheckBox[index].BackgroundImage = imageList.Images[index];
                    m_isCheckedA = false;
                }
                else
                {
                    m_waveSelectCheckBox[index].BackgroundImage = imageList.Images[index - 3];
                    m_isCheckedB = false;
                }
            }
        }

        private void trackBar_Scroll_Scroll(object sender, EventArgs e)
        {
            timer_outputData.Interval = trackBar_Scroll.Value;
            time_fre = Math.Round(1000.0 / (m_PointCountPerWave * trackBar_Scroll.Value), 2);
            textBox2.Text = time_fre.ToString();
            label_interval.Text = trackBar_Scroll.Value.ToString() + "ms";
        }

        private void button_manualA_Click(object sender, EventArgs e)
        {
            for (int i = 0; i < 3; i++)
            {
                m_waveSelectCheckBox[i].Checked = false;
                m_waveSelectCheckBox[i].BackgroundImage = imageList.Images[i];
            }
            m_isCheckedA = false;
            double.TryParse(textBox_valueA.Text, out m_dataScaled[0]);
        }

        private void button_manualB_Click(object sender, EventArgs e)
        {
            for (int i = 3; i < 6; i++)
            {
                m_waveSelectCheckBox[i].Checked = false;
                m_waveSelectCheckBox[i].BackgroundImage = imageList.Images[i - 3];
            }
            m_isCheckedB = false;
            double.TryParse(textBox_valueB.Text, out m_dataScaled[1]);
        }

        private void checkBox_sineA_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            timer_outputData.Start();
            button1.Enabled = false;
            button2.Enabled = true;
            button3.Enabled = true;
            flag_start = true;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            timer_outputData.Stop();
            button1.Enabled = true;
            button2.Enabled = false;
            button3.Enabled = true;
            flag_start = false;

        }

        private void button3_Click(object sender, EventArgs e)
        {
            timer_outputData.Stop();
            button1.Enabled = true;
            button2.Enabled = false;
            button3.Enabled = false;
            flag_start = false;
            time_count = 0;
            chart1.Series["Series1"].Points.Clear();
            chart1.Series["Series2"].Points.Clear();
            chart1.ChartAreas[0].AxisX.Minimum = 0;
            chart1.ChartAreas[0].AxisX.Maximum = 4000;
            totalpoints = double.PositiveInfinity;
            open_file = true;
            len = 0;
            len_count = 0;
        }

        private void textBox_valueB_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged_1(object sender, EventArgs e)
        {
            chart1.Series["Series1"].Points.Clear();
            chart1.Series["Series2"].Points.Clear();
            time_count = 0;
            chart1.ChartAreas[0].AxisX.Minimum = 0;
            chart1.ChartAreas[0].AxisX.Maximum = 4000;
            m_wavePointsIndexA = 0;
            m_wavePointsIndexB = 0;
            uint.TryParse(textBox1.Text, out m_PointCountPerWave);
            m_waveformGenerator = new WaveformGenerator(m_PointCountPerWave);
            time_fre = Math.Round(1000.0 / (m_PointCountPerWave * trackBar_Scroll.Value), 2);
            textBox2.Text = time_fre.ToString();
        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {
            double.TryParse(textBox2.Text, out time_fre);
            if (time_fre != 0)
            {
                chart1.Series["Series1"].Points.Clear();
                chart1.Series["Series2"].Points.Clear();
                time_count = 0;
                chart1.ChartAreas[0].AxisX.Minimum = 0;
                chart1.ChartAreas[0].AxisX.Maximum = 4000;
                m_wavePointsIndexA = 0;
                m_wavePointsIndexB = 0;

                int n;
                n = (int)(1000 / (time_fre * m_PointCountPerWave));
                trackBar_Scroll.Value = n;
                timer_outputData.Interval = n;
            }

        }

        private void chart1_Click(object sender, EventArgs e)
        {

        }

        private void textBox3_TextChanged(object sender, EventArgs e)
        {
            double.TryParse(textBox3.Text, out totalpoints);
        }

        private void button4_Click(object sender, EventArgs e)
        {
            openFileDialog1.Filter = "�ı��ļ�(*.txt)|*.txt";
            if (openFileDialog1.ShowDialog() == DialogResult.OK)
            {
                paintLine();
                open_file = false;
            }
          
        }
        private void paintLine()
        {

            string[] datas = File.ReadAllLines(openFileDialog1.FileName);
            foreach (string str in datas)
            {
                string[] strs = str.Split(',');
                file_x[len] = Convert.ToDouble(strs[0]) * 100;
                file_y[len] = Convert.ToDouble(strs[1]);
                len++;
            }
            //for (int i = 0; i < len; i++)
            //{ chart1.Series["Series1"].Points.AddXY(file_x[i], file_y[i]); }

        }

    }
}